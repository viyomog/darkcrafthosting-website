// Register GSAP ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

// Hero Section Animations
gsap.from('.hero-title', {
    duration: 1,
    y: 50,
    opacity: 0,
    delay: 0.5
});

// Start typing effect after the hero title appears
gsap.to('.typing-text', {
    duration: 0,
    opacity: 1,
    delay: 1.5
});

gsap.from('.hero-subtitle', {
    duration: 1,
    y: 30,
    opacity: 0,
    delay: 2.5
});

gsap.from('.hero-cta', {
    duration: 1,
    y: 30,
    opacity: 0,
    delay: 3
});

// Navbar Scroll Effect
window.addEventListener('scroll', () => {
    const nav = document.querySelector('nav');
    if (window.scrollY > 100) {
        nav.classList.add('shadow-lg');
    } else {
        nav.classList.remove('shadow-lg');
    }
});

// Smooth Scroll
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Plan Cards Animation
gsap.from('.plan-card', {
    scrollTrigger: {
        trigger: '#plans',
        start: 'top center'
    },
    duration: 0.8,
    y: 50,
    opacity: 0,
    stagger: 0.2
});

// Minecraft Particles
function createParticle() {
    const particle = document.createElement('div');
    particle.className = 'particle';
    particle.style.left = Math.random() * window.innerWidth + 'px';
    document.querySelector('#hero').appendChild(particle);

    setTimeout(() => {
        particle.remove();
    }, 3000);
}

setInterval(createParticle, 200);
