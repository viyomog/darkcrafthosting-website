# Darkcraft Hosting Website

A modern, responsive Minecraft server hosting website with stunning animations and interactive elements.

## Features

- Responsive design that works on all devices
- Smooth animations and transitions using GSAP
- Interactive 3D globe showing server location (Mumbai, India)
- Minecraft-themed UI elements and particles
- Dynamic pricing cards with hover effects
- Smooth scroll navigation

## Setup

1. Clone this repository
2. Open `index.html` in your web browser
3. No build process required - the website uses CDN-hosted dependencies

## Dependencies

- Tailwind CSS (v2.2.19) for styling
- GSAP (v3.12.2) for animations
- Three.js (r128) for 3D globe
- All dependencies are loaded via CDN

## Structure

```
darkcraft-website/
├── css/
│   └── style.css
├── js/
│   └── main.js
├── images/
│   └── minecraft-bg.jpg (add your own background)
├── index.html
└── README.md
```

## Customization

- Replace `minecraft-bg.jpg` with your own background image
- Modify colors in `style.css` to match your brand
- Update pricing and plan details in `index.html`
- Customize animations in `main.js`

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
